# AtmoSync — Micro-Climate Arbitrage Analytics

A complete, runnable implementation of Project 1 (Kafka → Snowflake → dbt → Superset).
See **AtmoSync_Project_Report.docx** for the full write-up, architecture mapping, and results.

## Run it yourself

```bash
pip install dbt-core dbt-duckdb duckdb faker

# 1. Generate IoT telemetry + commodity pricing reference data
python3 scripts/01_iot_simulator.py
python3 scripts/generate_commodity_prices.py

# 2. Stream events through the (simulated) Kafka layer
python3 scripts/02_kafka_producer_consumer.py

# 3. Load into the warehouse (DuckDB stands in for Snowflake)
python3 scripts/03_load_warehouse.py

# 4. Transform with dbt
cd dbt_project
export DBT_PROFILES_DIR=$(pwd)
dbt run
dbt test

# 5. Open atmosync_dashboard.html in a browser to view the final result
```

## Folder guide

| Path | What it is |
|---|---|
| `scripts/01_iot_simulator.py` | Generates 72h of container telemetry, with an injected temperature drift on CTR-A1 (avocados) |
| `scripts/02_kafka_producer_consumer.py` | Real Kafka producer/consumer code + a runnable local shim |
| `scripts/03_load_warehouse.py` | Loads raw events into the warehouse (DuckDB / Snowflake-compatible SQL) |
| `dbt_project/` | Full dbt project — staging models, the Spoilage Arbitrage mart model, and schema tests |
| `data/final_spoilage_arbitrage.csv` | The final business output: per-container reroute recommendations |
| `atmosync_dashboard.html` | The executive BI dashboard (Superset stand-in) |
| `atmosync.duckdb` | The built warehouse file — open with any DuckDB client to run your own SQL |
| `AtmoSync_Project_Report.docx` | Full project report: architecture, metric methodology, results, production migration guide |

## Moving to real infrastructure
- **Kafka**: swap `LocalBrokerShim` for `KafkaProducer`/`KafkaConsumer` (see the `REAL_PRODUCER_CODE`/`REAL_CONSUMER_CODE` reference blocks in `02_kafka_producer_consumer.py`).
- **Snowflake**: uncomment the `prod` target in `dbt_project/profiles.yml`, set `SNOWFLAKE_*` env vars, run `dbt run --target prod`. No model SQL changes needed.
- **Superset**: point a Superset instance at the same warehouse schema and rebuild the dashboard panels as native Superset charts against `analytics.spoilage_arbitrage` and `analytics.container_health_snapshot`.
